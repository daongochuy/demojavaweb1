package com.example.demo.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.Model.lotteryType;
import com.example.demo.Repository.RepositoryLotteryType;
@Service
@Transactional
public class lotteryTypeServiceImpl implements lotteryTypeService {
    @Autowired
     RepositoryLotteryType resLotType;

	@Override
	public List<lotteryType> getAllLotteryType() {
		// TODO Auto-generated method stub
		return resLotType.findAll();
	}

	@Override
	public void saveLotType(lotteryType myLotType) {
		this.resLotType.save(myLotType);
		
	}

	@Override
	public Page<lotteryType> GetAllLotteryType(int PageNo) {
		// TODO Auto-generated method stub
		Pageable page=PageRequest.of(PageNo, 10);
		return this.resLotType.findAll(page);
	}
   

}
