package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyWebappdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyWebappdemoApplication.class, args);
	}

}
