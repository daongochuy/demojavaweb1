package com.example.demo.Services;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.example.demo.Model.lotteryType;

public interface lotteryTypeService {
	public List<lotteryType> getAllLotteryType();
	public void saveLotType(lotteryType myLotType);
	Page<lotteryType> GetAllLotteryType(int PageNo);

}
