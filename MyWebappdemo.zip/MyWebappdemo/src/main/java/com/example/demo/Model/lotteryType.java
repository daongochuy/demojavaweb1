package com.example.demo.Model;


import jakarta.persistence.*;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name="lottery_type")
public class lotteryType {
	@Id
	@Column(name="id")
	String Id;
	@Column(name="name")
	String Name;
	@Column(name="parentid")
	String ParentID;
	@Column(name="is_enable")
	Boolean isEnable;
	@Column(name="show_on_home")
	Boolean ShowOnHome;
	public String getId() {
		return Id;
	}
	public lotteryType()
	{
		
	}
	public lotteryType(String id, String name, String parentID, Boolean isEnable, Boolean showOnHome) {
		super();
		Id = id;
		Name = name;
		ParentID = parentID;
		this.isEnable = isEnable;
		ShowOnHome = showOnHome;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getParentID() {
		return ParentID;
	}
	public void setParentID(String parentID) {
		ParentID = parentID;
	}
	public Boolean getIsEnable() {
		return isEnable;
	}
	public void setIsEnable(Boolean isEnable) {
		this.isEnable = isEnable;
	}
	public Boolean getShowOnHome() {
		return ShowOnHome;
	}
	public void setShowOnHome(Boolean showOnHome) {
		ShowOnHome = showOnHome;
	}

}
