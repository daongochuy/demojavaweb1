package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Model.lotteryType;

@Repository
public interface RepositoryLotteryType extends JpaRepository<lotteryType,String> {

}
