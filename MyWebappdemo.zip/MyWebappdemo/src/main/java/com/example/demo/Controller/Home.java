package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.Model.lotteryType;
import com.example.demo.Services.lotteryTypeService;

@Controller
public class Home {
	@Autowired
	lotteryTypeService lotTyService;
	@GetMapping("/Home")
	public String toHome(Model model)
	{  
		model.addAttribute("listLotType", lotTyService.getAllLotteryType());
		return "index";
	}
	@GetMapping("/LotteryType")
	public String toPageLotType(Model model)
	{   
		int PageNo=1;
		Page<lotteryType> pageLotterType=lotTyService.GetAllLotteryType(PageNo);
		List<lotteryType> lstLotType=pageLotterType.getContent();
		long totalItems=pageLotterType.getTotalElements();
		int TotalPages=pageLotterType.getTotalPages();
		model.addAttribute("lstLotteryType", lstLotType);
		model.addAttribute("currentPage", PageNo);
		return "LotteryType";
	}
	@GetMapping("/AddLotteryType")
	public String AddLotteryType(Model model)
	{  
		lotteryType lotType=new lotteryType();
		model.addAttribute("lotteryTy", lotType);
		return "AddLotType";
	}
	@PostMapping("/SaveLotteryType")
	public String SaveLoteryType(@ModelAttribute("lotteryTy")lotteryType mylotType, Model model) {
		this.lotTyService.saveLotType(mylotType);
		return "redirect:/AddLotteryType";
	}

}
