package com.example.demo.Model;

import java.sql.Date;



import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name="lottery")
public class lottery {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	long ID;

	 @Column(name="typelottery")
	String lotteryType;
	 @Column(name="serialnumber")
	int serialNumber;
	@Column(name="Images")
	String image;
	@Column(name="Detail")
	String detail;
	@Column(name="Price")
	double price;
	@Column(name="PromotionPrice")
	double promotionPrice;
    @Column(name="includeVAT")
	boolean includeVAT;
	@Column(name="createdate")
	Date createDate;
	@Column(name="enddate")
	Date endDate;
	@Column(name="quantity")
	int quantity;
	@Column(name = "isEnable")
	boolean Enable;
	@Column(name="show_on_home")
	boolean showOnHome;
    @Column(name = "viewCount")
	int viewCount;
    public lottery() {
    	
    }
	public lottery(String lotteryType, int serialNumber, String image, String detail, double price,
			double promotionPrice, boolean includeVAT, Date createDate, Date endDate, int quantity, boolean enable,
			boolean showOnHome, int viewCount) {
		super();
		this.lotteryType = lotteryType;
		this.serialNumber = serialNumber;
		this.image = image;
		this.detail = detail;
		this.price = price;
		this.promotionPrice = promotionPrice;
		this.includeVAT = includeVAT;
		this.createDate = createDate;
		this.endDate = endDate;
		this.quantity = quantity;
		Enable = enable;
		this.showOnHome = showOnHome;
		this.viewCount = viewCount;
	}
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	public String getLotteryType() {
		return lotteryType;
	}
	public void setLotteryType(String lotteryType) {
		this.lotteryType = lotteryType;
	}
	public int getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getPromotionPrice() {
		return promotionPrice;
	}
	public void setPromotionPrice(double promotionPrice) {
		this.promotionPrice = promotionPrice;
	}
	public boolean isIncludeVAT() {
		return includeVAT;
	}
	public void setIncludeVAT(boolean includeVAT) {
		this.includeVAT = includeVAT;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public boolean isEnable() {
		return Enable;
	}
	public void setEnable(boolean enable) {
		Enable = enable;
	}
	public boolean isShowOnHome() {
		return showOnHome;
	}
	public void setShowOnHome(boolean showOnHome) {
		this.showOnHome = showOnHome;
	}
	public int getViewCount() {
		return viewCount;
	}
	public void setViewCount(int viewCount) {
		this.viewCount = viewCount;
	}

}
